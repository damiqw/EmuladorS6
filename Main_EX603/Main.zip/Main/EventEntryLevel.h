#pragma once

void InitEventEntryLevel();
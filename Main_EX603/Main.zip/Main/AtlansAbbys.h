#pragma once 

void InitAtlansAbbys();